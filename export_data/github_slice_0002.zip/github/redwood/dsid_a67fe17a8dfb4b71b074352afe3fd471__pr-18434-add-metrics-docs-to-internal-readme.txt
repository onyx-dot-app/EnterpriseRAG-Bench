This is a small documentation-only PR to make the new prefix/KV cache telemetry usable by oncall and platform operators without having to hunt through Slack threads or dashboard PRs. It adds an internal README section that (1) defines the cache metrics in plain language (including what counts as hit/miss, partial reuse, and how streaming retries are handled), (2) provides “how to interpret” guidance with common failure modes (capacity/eviction pressure, TTL expiry, policy disabled, hash/version mismatch), (3) documents label/aggregation expectations to avoid cardinality surprises, and (4) links directly to the dashboards + runbook.

Motivation: We’ve had a few iterations on naming + semantics (see the ADR and the recent rename PR) and SRE asked for a single canonical place to point oncall when hit-rate dips or when metrics appear to go missing.

What’s included: - New README section: “Cache Telemetry (prefix + KV): metrics, semantics, and triage” - Quick links to Grafana dashboards (prod + canary) and the incident runbook - Guidance on dashboards: which panels answer which questions (hit-rate vs eviction pressure vs wasted prefill) - Notes on sampling and why some counters/histograms may not match 1:1 with request totals - “Gotchas” section: streaming retries, continuous batching attribution, rollout mismatch between gateway tags and runtime allowlists

Not included: No runtime/instrumentation changes, no dashboard changes, no alert rule changes.

References: - ADR: prefix/KV cache hit-rate definition - Observability standards: cache metrics naming + cardinality policy - Dashboard spec: cache hit-rate dashboards + alerting panels

Testing: Docs only.

Rollout: None (internal docs).
Omar El-Sayed (review): Can we be explicit about whether hit-rate is computed over requests, sequences, or tokens? A bunch of confusion in the earlier thread came from “hit-rate” meaning different denominators.

Nadia Rahman (author): Good call. Updated the README to include (a) request-level hit boolean vs token-level reuse ratio, and (b) which dashboard panels use which denominator. Also added a short note on why token-level is preferred for workload mix changes.

Logan Wright (review): Please add a warning about label cardinality: route_id + model_version is ok, but we should discourage tenant_id and raw prompt hash. Also call out that prompt length is bucketed.

Nadia Rahman (author): Added a “Cardinality / Labels” section with an allowlist summary and examples of safe queries. Explicitly called out that we do not emit raw prompt text and that prompt-length/token-count are histogram buckets.

Allison Grant (review): Dashboard links: can you include both prod and perf-canary, and link the runbook for pipeline drops? Also, suggest a first triage order when hit-rate dips (check ingestion health vs real miss reasons).

Nadia Rahman (author): Done. Added links for prod + canary dashboards and the pipeline incident runbook, plus a 5-step triage checklist: (1) ingestion drop panel, (2) hit-rate trend by region/model, (3) miss reason breakdown, (4) eviction/pressure, (5) wasted prefill.

Noah Patel (review): Minor: align terminology—use “prefix cache” consistently and note how it relates to KV reuse. Also mention streaming retry double-counting was fixed in 18428.

Nadia Rahman (author): Updated terminology and added a short “Recent fixes” note referencing the retry double-counting fix and batched-prefill attribution fix.

Approvals: Omar approved. Logan approved. Allison approved.

Merge: Squash + merge after CI green.