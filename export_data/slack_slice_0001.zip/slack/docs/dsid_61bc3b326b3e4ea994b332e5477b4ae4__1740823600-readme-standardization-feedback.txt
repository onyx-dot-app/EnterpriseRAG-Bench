Elliot Price: Dropping this here bc we’re seeing drift across the template READMEs (Python vs TS, RAG vs agent) and it’s starting to confuse reviewers + internal beta folks. Can we align on a standard README skeleton + troubleshooting sections this week? I want something we can point DES-377 and PR-114 at.

Wei Chen: +1. Right now the “Quickstart” steps differ in ordering (some start with cloning repo, others start with env vars), and the error guidance is inconsistent (e.g. 401 vs 403 wording). I can propose a canonical structure.

Monica Patel: Please do. Also: we need the README to match what the CLI `init` outputs (folder names, default port, etc). Some of the old scaffolds still reference `./server.py` but new is `./app/main.py`.

Renee Sullivan: From user tests: they scan for 3 things first: “what do I run”, “how do I know it worked”, “what breaks most often”. If we standardize that, we’ll reduce the :sad-parrot: churn.

Priya Shah: Adding support angle — top issues we’re already seeing internally: 
1) missing `REDWOOD_API_KEY` (or set but wrong org/project), 
2) OTel collector not receiving traces (compose not running / endpoint mismatch), 
3) 429 rate limits with default concurrency, 
4) streaming disconnects behind corp proxies, 
5) tool schema parse errors (agents).
If README has a “Common errors” table w symptoms->fix, it’ll deflect a bunch.

Elliot Price: That’s exactly what I want. Wei, can you drop a proposed outline here? Ideally: consistent headers, consistent naming, and a checklist “Success criteria” section.

Wei Chen: Draft skeleton (feel free to bikeshed names):

```
# <Template name> (RAG + Agents)

## What you’ll build
- 1–2 bullets (include deployment mode assumptions: Hosted API by default)

## Prereqs
- Redwood account + API key
- Python 3.11+ / Node 18+
- (Optional) Docker for local OTel collector

## Quickstart (5–10 minutes)
1) Get the code
2) Configure environment
3) Install deps
4) Run the app
5) Try a sample request

## Verify it worked
- Expected console output
- Where to see `x-redwood-request-id`
- “You should see spans named …” + how to confirm locally

## Configuration
- Table of env vars (required/optional)
- Default model pin + how to change
- Cost controls (max_tokens, concurrency)

## How it works (high level)
- RAG pipeline diagram-ish bullets
- Agent loop + tool calling summary

## Observability
- Metrics emitted (names + what they mean)
- Traces: span hierarchy + required attributes
- Logs: redaction + correlation IDs

## Deployment
- Local
- Docker
- (Optional) Fly/Render/k8s links (if we’re including)

## Troubleshooting
- Common errors (401/429/timeouts/tool schema)
- Streaming disconnect notes + proxy considerations
- OTel collector not receiving traces

## Security notes
- Secrets handling
- PII/logging guidance

## Next steps
- Link to docs walkthrough + eval harness
```

Monica Patel: Looks good. One nuance: “Verify it worked” should include both functional (you got an answer) AND operational (you emitted telemetry). For operational, I’d like a copy/paste command: `./scripts/verify_observability` (from examples) if we can keep it consistent.

Allison Grant: +1 on separating functional vs signals. Also please keep attributes/tags guidance in the README minimal and link to the observability reference. Folks keep adding “helpful” dimensions that explode cardinality. Maybe add a callout: “Do not add user_id / email / raw prompt as attributes.”

Renee Sullivan: Can “Verify it worked” include literal screenshots? (or at least exact strings) Internal beta folks didn’t know what “collector running” means.

Elliot Price: For the repo README we can do exact strings; screenshots belong in docs site page. But we can include “Expected output” blocks.

Priya Shah: For troubleshooting, please include *symptoms* not just causes. Example:
- Symptom: `401 Unauthorized` -> check `REDWOOD_API_KEY`, key scope, org/project
- Symptom: `429 Too Many Requests` -> reduce `RAG_CONCURRENCY`, enable backoff, see rate limits
- Symptom: “hangs / no tokens when streaming” -> proxy buffering, use `--no-buffer` config, try non-streaming to isolate.
Support tickets are written in symptoms.

Wei Chen: Makes sense. I’ll draft a standard “Common errors” section template we can paste into both languages w minimal code divergence.

Monica Patel: Also: we should standardize the naming of env vars referenced in README. Right now TS uses `REDWOOD_BASE_URL` and Python uses `REDWOOD_API_BASE`. We’re trying to converge. Until then, README must match code *exactly*.

Elliot Price: Yeah. If the var names differ by language, the README template should say “See `.env.example` for the authoritative list” + include a table generated from schema (once ENG-4187 lands). For now: keep a small hand-written table and point to `.env.example`.

Allison Grant: Another thing: for “Observability” section, can we standardize the headings too?
- Traces
- Metrics
- Logs
And for each: one “What you get” bullet list + one “How to validate locally” bullet list.

Renee Sullivan: + add “How to file a good bug” (copy/paste these logs, include request id). That’s huge for community support.

Priya Shah: Yes please. “Include `x-redwood-request-id` and template version stamp” would be ideal.

Talia Benson: Pulling this together into action items:
1) Wei to write canonical README outline + troubleshooting snippet (today/tomorrow)
2) Elliot to align w docs IA (where this pattern shows up in docs pages)
3) Monica to confirm which env vars + folder layout are final for v1 so docs don’t churn
4) Allison to add a short redaction/cardinality callout text we can reuse
Does that match?

Elliot Price: Yep. Also I’ll comment on DES-377 that this thread is the source of truth. Wei, when you have a draft, paste it into the design ticket + ping me for review.

Wei Chen: Will do. I’ll include a “Troubleshooting: OTel collector” section with exact docker-compose commands + common endpoint mismatch examples.

Monica Patel: Please include the note about telemetry tagging headers being opt-in. We had that proxy rejection incident; README should say “If you’re behind a corporate proxy, disable template telemetry tags” (or whatever the final flag is).

Elliot Price: Good call. Let’s add a troubleshooting entry: “Requests fail only on corporate network” -> disable extra headers / check proxy allowlist.

Allison Grant: + remind folks: telemetry tag must NOT include any customer identifiers. Keep it to template name/version only.

Renee Sullivan: If we can keep the first 10 lines of the README identical across templates, even better. People compare them side-by-side.

Elliot Price: Agree. Goal: consistent “What you’ll build / Quickstart / Verify it worked / Troubleshooting” ordering across every template.

Wei Chen: I’ll draft and share. :thumbsup:

Talia Benson: Cool. Marking as owner thread; I’ll follow up in standup tomorrow if the draft isn’t in DES-377 yet.