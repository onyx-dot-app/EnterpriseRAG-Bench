samira: Anyone else hit failures in the Go quickstart? New hires reported crash when they copy/paste.

evan: Which part?

samira: examples/go/quickstart/README.md. The snippet uses `client := redwood.NewClientWithKey("...")` which we removed in favor of `NewClientFromEnv()`. Also the retry example spawns a goroutine that loops forever on error.

evan: yikes. paste?

samira: ```go
package main
import "github.com/redwood-inference/redwood-go"
func main() {
  client := redwood.NewClientWithKey("sk_live_XXX")
  go func() {
    for {
      _, err := client.Generate("hi")
      if err != nil {
        // retry forever
        continue
      }
      break
    }
  }()
}
```

samira: That goroutine busy-loop can spin CPUs and never back off. Also the response usage field in the sample prints `res.Usage.Tokens` which is old; new struct is `res.Usage.TotalTokens`.

evan: OK we should: 1) change to NewClientFromEnv(), 2) show a cancellable context + exponential backoff with max attempts, and 3) fix the struct field.

golang-bot: Recommended patch: use `client := redwood.NewClientFromEnv()` + `backoff := time.Millisecond * 500` doubling with attempts and use `context.WithTimeout` to cancel after N tries.

evan: I'll open a docs PR that replaces the snippet, adds a tiny unit test in examples/go/__tests__ that runs the snippet with a mocked client, and adds a grep check for `NewClientWithKey\(|Usage.Tokens` in docs CI.

docs-bot: PR opened by evan: https://github.com/redwood-inference/docs/pull/4315  fixes Go quickstart to use env auth, replaces busy-loop retry, updates usage field, adds snippet test.

samira: Also let's add a checklist item to onboarding: "run language-specific quickstarts (go/node/python) against latest SDK". New hires keep pasting snippets into prod code.

evan: Agreed. I'll add the CI grep and update onboarding docs in the PR.

samira: thanks. happy to review the PR. :thumbsup:
