marta: Quick heads-up from a docs sweep: found multiple README examples that define a local constant like `const API_KEY = 'PUT_YOUR_KEY_HERE'` and then call fetch with it. That pattern keeps showing up in generated examples and encourages copy/paste of secrets.

vik: ouch. which directories?

marta: examples/embed-widget, quickstarts/js, and docs/static/snippets. The TS snip also uses the old package import which fails for folks installing @redwood/inference.

ben: We should switch all snippets to SDK-first and env var guidance. Proposed standard: REDWOOD_API_KEY. Node example: `const client = new RedwoodClient({ apiKey: process.env.REDWOOD_API_KEY })`. Python: `client = RedwoodClient(api_key=os.getenv('REDWOOD_API_KEY'))`.

vik: Also add a 1-line about local secrets management: use direnv or a gitignored .env file and never commit keys.

marta: I'm going to replace inline-key samples and add a brief "example hygiene" note to CONTRIBUTING.md: no plaintext keys in examples; prefer SDK constructor; include retry/backoff mention.

ci-bot: lint/docs: scanning changed files for disallowed tokens... found `PUT_YOUR_KEY_HERE` in examples/embed-widget/README.md

ben: I'll update the docs generator template in infra/docs-templates so future generated snippets are SDK-first and include mac/linux + PowerShell env var examples. Add a unit test to assert `RedwoodClient` appears in generated output.

vik: Can we add a docs CI check that fails if `PUT_YOUR_KEY_HERE` or `YOUR_KEY` or `INSERT_KEY` appear in rendered docs? Make it run on PRs and main builds.

marta: Yep, adding a job named `no-inline-keys` that greps rendered HTML and fails on matches. Also adding a small smoke test that renders sample pages and asserts no literal tokens.

doc-bot: Draft PR: https://github.com/redwood-inference/docs/pull/1102 branch: docs/remove-inline-keys-preview. Preview: https://deploy.preview/1102

ben: I patched the TypeScript examples to `import { RedwoodClient } from '@redwood/inference'` and fixed a broken snippet that assumed the old default export.

vik: After merge, let's post a short note in #announcements and pin a link to the CONTRIBUTING change. Might save future churn.

marta: PR ready for review. Also adding changelog entry and test plan.

doc-bot: docs CI passed for branch; PR merged. 9 files updated.

ben: I'll sweep external example repos (widget, tutorial, demo) and open follow-ups for anything still using inline keys.

marta: thanks team. small change but high impact for new users and security.