Create a set of modular onboarding assets for the Template Apps reference repositories used in Quickstarts and README docs. Goal: produce a small, reusable library of annotated screenshots, lightweight architecture diagrams, and short animated GIFs that illustrate developer setup (hosted vs private), SDK initialization, streaming responses, and console rollout panels. Assets should be easy-to-drop into GitHub READMEs, docs pages, and marketing one-pagers. Scope includes desktop and mobile screenshots, dark/light variants, 2 architecture diagrams (hosted API flow, private VPC deployment flow), 3 README diagrams (quickstart steps, SDK callouts, rollout example), 4 animated GIFs (init + stream, local dev->deploy, canary rollout), and a compressed asset package for the docs repo.
figma: Template-App-Quickstart-Board (final frames)
screenshots: template-app-desktop-light.png
screenshots: template-app-desktop-dark.png
screenshots: template-app-mobile-light.png
diagrams: hosted-api-flow.svg
diagrams: private-vpc-flow.svg
readme-diagrams: quickstart-steps.svg
readme-diagrams: sdk-callouts.png
gifs: init-and-stream.gif
gifs: local-to-deploy.gif
asset-pack: template-onboarding-assets-2026-03.zip
All visual assets exported at required sizes and in two color modes (light/dark)
Diagrams produced as SVG for docs and PNG fallback for GitHub README
Animated GIFs under 3MB and loop cleanly; 1080x540 recommended
Assets uploaded to Drive + linked in PR; README example updated in template repo with final assets
Design review approved by PM and Developer Advocate; UX annotation accepted by engineering
2026-03-02 Maya Thompson: Kickoff done with PM and DevRel. Aligning on two primary flows (hosted vs private). Added initial list of required screenshots and GIF stories.
2026-03-04 Ethan Liu: Uploaded first-pass frames to Figma. Need engineering to confirm that console UI used in screenshots will be stable for the release.
2026-03-06 Connor Reyes (DevRel): Reviewed frames. Suggested adding a small SDK callout overlay to the streaming screenshot to show header+token usage. Also requested smaller GIF demonstrating prefix caching behavior.
2026-03-09 Maya Thompson: Updated diagrams per feedback (added cache icon and fallback path). Started exporting light variants. Created PR draft updating README usage example.
2026-03-11 PM review (Aisha Patel): Approved visuals but requested alternate copy for the private deployment diagram to emphasize audit logs and KMS note. Assigned copy update back to design.
2026-03-12 Ethan Liu: Uploaded dark-theme screenshots and generated optimized GIFs. Linked PR: https://github.com/redwood-inference/template-app/pull/142. Pending final sign-off from DevRel and engineering QA on 2026-03-15.
Avoid using production customer data in screenshots; use mock org 'Acme Labs'. Include pixel-perfect spacing for README thumbnails (max width 680px). Document export settings in Figma file cover. Provide markdown snippet for README with both light/dark img tags and alt text.