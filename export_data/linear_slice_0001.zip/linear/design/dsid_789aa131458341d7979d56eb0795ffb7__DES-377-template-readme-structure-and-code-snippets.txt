## Context
We are shipping Redwood “Quickstart templates” (initially Python + TypeScript) for RAG + agents that are production-minded by default. Internal beta feedback + Solutions Engineering notes show that README quality is the #1 driver of time-to-first-success and support deflection.

Today, each template has slightly different:
- Setup steps (env vars, prerequisites, model config)
- How we present streaming + tool calling snippets
- Troubleshooting format and error messages
- How we explain observability verification (OTel collector, dashboards, request IDs)

This ticket defines a *standard README structure* and *code snippet formatting conventions* that all quickstart templates must follow, so users can reliably scan, copy/paste, and debug.

## Goals
1) Make the first 5 minutes deterministic: install → configure → run → verify.
2) Align terminology and sections across Python/TS templates (and future languages).
3) Reduce support load by adding a consistent troubleshooting section with the top failure modes (401/429/timeouts/collector issues/tool schema failures/retrieval empty).
4) Ensure code snippets are copy/paste friendly, safe by default, and consistent with Redwood SDK patterns (timeouts/retries, request ID propagation, optional telemetry tags).

## Non-goals
- Rewriting product docs IA (tracked separately by docs IA work).
- Changing SDK API surface (tracked in SDK tickets).
- Adding new template functionality (RAG pipeline, agent loop, vector store adapters).

---

## Proposed README Template (v1)
Each template README MUST follow this section order and naming (minor language-specific adjustments allowed):

### 1. Title + one-liner
- Format: “RAG + Agents Quickstart (Python)” / “RAG + Agents Quickstart (TypeScript)” 
- One sentence: what it does + why it’s production-minded (timeouts/retries/OTel/cost controls).

### 2. What you’ll build
Bullets (3–5) with concrete behaviors, e.g.:
- Streams answers with citations
- Runs a tool-calling agent loop (max iterations enforced)
- Emits traces/metrics/logs (OpenTelemetry)

### 3. Architecture (quick visual + 6–10 lines)
- Short text diagram showing request flow:
  User → API server → Retriever → Redwood API (LLM) → Tools → Response
- Mention observability surfaces: traces, metrics, structured logs.
- Link to deeper docs page (to be added in redwood-docs).

### 4. Prerequisites
- Redwood API key
- Runtime version constraints (Python >= 3.10 / Node >= 18)
- Docker (optional, for local collector)
- Note: “Do not commit .env; use env vars or your secrets manager.”

### 5. Quickstart (local)
**Must be 4–6 steps max** and include expected output.
1) Clone / scaffold
2) Install deps
3) Configure env vars
4) Start services
5) Run a sample request
6) (Optional) Verify observability

Include a single canonical “hello” command per language.

### 6. Configuration
Split into:
- Required env vars (table)
- Optional env vars (table)
- Defaults (explicit: timeouts, retries, max_tokens, concurrency)

Env var table format:
- NAME | Required | Default | Description | Example

### 7. Running the app
- Local dev
- Docker
- Production notes (short, non-prescriptive): reverse proxies, timeouts, streaming caveats.

### 8. Observability (verify in 2 minutes)
Include:
- “How to confirm traces are working” (what to look for)
- “How to confirm metrics are working” (what to look for)
- “Where to find Redwood request IDs” (log field naming)

This section should be mostly identical across templates.

### 9. Cost & performance controls
Short list of levers exposed by templates:
- max_tokens
- model selection/pinning
- retrieval top_k / chunk size
- streaming vs non-streaming

### 10. Troubleshooting
Must include:
- A short “Before you dig in” checklist
- Top issues with: symptom → likely cause → fix → how to validate

Standard subsections:
- Auth (401/403)
- Quota / Rate limiting (429)
- Timeouts / Streaming disconnects
- Tool calling / Schema validation errors
- Retrieval empty / poor results
- OTel collector not receiving traces

### 11. Security notes
- Secrets handling guidance (don’t log keys; don’t commit .env)
- PII/logging redaction reminder
- Safe defaults recap (timeouts/retries/max iterations)

### 12. FAQ
Max 6 items. Must include:
- “Can I swap the model?”
- “Can I bring my own vector DB?”
- “Can I run this in VPC/on-prem?” (link to Redwood Private guidance)

### 13. License + Contributing
- Point to repo-level docs

---

## Code Snippet Conventions (applies across README + inline docs)
### General
- Snippets must be runnable without hidden steps.
- Prefer single-responsibility snippets; avoid skipping imports.
- Use consistent naming:
  - `REDWOOD_API_KEY`, `REDWOOD_BASE_URL`, `REDWOOD_MODEL`
  - `REQUEST_TIMEOUT_MS`, `MAX_TOKENS`, `RETRY_MAX_ATTEMPTS`
- Any snippet that logs must demonstrate redaction-safe logging (or omit sensitive fields).

### Formatting
- Use fenced code blocks with language tags: ```python / ```ts / ```bash / ```yaml.
- Use `$` prefix only for shell commands.
- Include “Expected output” blocks for the first run.

### Snippet Patterns (canonical)
1) Client initialization (with timeouts/retries)
- Use the shared template config loader in examples (avoid ad-hoc `process.env` reads sprinkled everywhere).

2) Streaming responses
- Always show proper stream consumption and error handling.
- Include a note on proxies/timeouts and where to adjust.

3) Tool calling snippets
- Demonstrate schema validation and “tool failed” handling.
- Show max iteration guardrails.

4) Retrieval snippets
- Show retriever interface usage; do not tie README to a single vector store vendor.

### Copy/paste “Safety” rules
- No real keys or endpoints.
- No sample prompts containing sensitive data.
- Avoid printing full model output in troubleshooting snippets; prefer truncated or hashed output when demonstrating logs.

---

## Troubleshooting Content Requirements (v1)
Each issue entry should have:
- **Symptom** (what user sees)
- **Likely causes** (2–3 bullets)
- **Fix** (commands/config)
- **Validate** (how to confirm it’s resolved)

Mandatory issues to include (based on support + internal beta):
1) 401 Unauthorized (missing/invalid key)
2) 429 Too Many Requests (template concurrency too high; need backoff)
3) Streaming disconnects (proxy idle timeout; SDK reconnect guidance)
4) Tool schema parse/validation errors (mismatch between tool schema and tool return)
5) Retrieval returns no documents (ingestion not run; wrong path; top_k)
6) OTel collector not receiving traces (endpoint misconfig; docker-compose not running)

---

## Deliverables
1) README markdown skeleton to be adopted across template repos (Python + TS).
2) A “snippet style guide” section (can live in repo root and be linked from each template README).
3) A standard troubleshooting block (shared text) with language-specific commands.

## Where this will be applied
- `redwood-quickstarts` repo
  - Python RAG+agent template
  - TypeScript RAG+agent template
- Any future quickstarts should start from the same README scaffold.

## Open Questions
1) Do we want a single repo-level README with per-template sub-READMEs, or fully self-contained template READMEs? (Proposal: self-contained per template + a short repo-level index.)
2) Should we add “Deploy” section in v1? (Proposal: keep it minimal and link to deployment recipes; don’t bloat the first-run path.)

## Acceptance Criteria
- Python and TypeScript templates share the same section headers and ordering (except where language-specific prerequisites differ).
- A user can complete Quickstart steps without reading beyond sections 1–6.
- Troubleshooting section includes the mandatory top issues and follows the symptom/causes/fix/validate pattern.
- Snippets follow formatting conventions and use the canonical env var names.

## Notes / References
- Related eng PRs:
  - Standard README work: `redwood-quickstarts` PR-114
  - Retry/timeouts defaults: PR-103
  - OTel instrumentation: PR-102
- Related docs PRs:
  - `redwood-docs` PR-842 (walkthrough)
  - `redwood-docs` PR-843 (troubleshooting)
- Stakeholders: Monica Patel (DevEx), Dana Lo (TS), Wei Chen (TW), Allison Grant (Obs)

2025-02-07 (Elliot Price): Created ticket after docs review noted inconsistent “Quickstart” steps across repos. Goal is to ship a single README standard before internal beta expands.
2025-02-10 (Wei Chen): Drafted README skeleton headings + env var table format. Added mandatory troubleshooting topics based on #help and Solutions Eng notes. Requesting DevEx review for accuracy on defaults (timeouts/retries/max_tokens).
2025-02-11 (Monica Patel): +1 on keeping Quickstart to 4–6 steps. Please make sure we explicitly call out model pinning and where to change it (env var). Also avoid mentioning internal product terms (“workflows”)—stick to RAG/agent loop per terminology thread.
2025-02-12 (Allison Grant): Observability section should be near the top but after Quickstart. Include: how to verify traces locally, what span names to expect, and warning about high-cardinality attributes. Keep example attributes minimal.
2025-02-14 (Dana Lo): TS streaming snippet needs to show abort handling and explicit note about reverse proxies. Also suggest we standardize on Node >= 18 to avoid fetch/stream quirks.
2025-02-18 (Wei Chen): Updated skeleton with: “Observability (verify in 2 minutes)”, “Cost & performance controls”, and a standardized troubleshooting format. Added security notes section with: don’t commit .env, avoid logging prompts/PII, redact tokens.
2025-02-20 (Renee Sullivan): From advocate perspective, include a short “What you’ll build” list and expected output for the first run. That helps demos and reduces anxiety for first-time users.
2025-02-21 (Elliot Price): Approved direction. Please coordinate with Sabrina to ensure smoke tests reference the same commands as README (avoid drift).
2025-03-01 (Wei Chen): Marking done. README standard adopted in `redwood-quickstarts` PR-114; troubleshooting language aligned with `redwood-docs` PR-843. Follow-up: ensure any future templates start from the same scaffold via CLI init.