From: sara.patel@vertexhealth.com
To: marissa_cole@redwood.com; ben_carter@redwood.com
Cc: jdavenport@vertexhealth.com; ops@vertexhealth.com
Date: 2027-06-05T09:12:00-07:00
Subject: POC lab — proposed week for hands-on run

Hi Marissa / Ben,

Thanks for the overview last week. The engineering team at VertexHealth is keen to get into a hands-on working session (prompt review + routing + run a short load sweep). We have an internal blackout on the 9th and 10th but are otherwise flexible the week of June 14.

Primary asks from our side:
- Walk through the prompt playbook and suggested routing policies for our triage flow
- Run small-scale load tests (up to ~10k tokens/sec aggregate) to validate batching knobs
- Confirm IAM and log export settings for audit purposes

Can you propose 2 slot options that also include a 60–75 minute deep-dive & a 30-minute follow-up for results and action items? Time zone: PDT.

Sara
Principal Product Manager
VertexHealth

From: marissa_cole@redwood.com
To: sara.patel@vertexhealth.com
Cc: ben_carter@redwood.com; sergio_alvarez@redwood.com; dev_patel@redwood.com
Date: 2027-06-05T11:05:00-07:00
Subject: Re: POC lab — proposed week for hands-on run

Sara — thanks, this is great context.

We can do two concrete proposals:
- Option A: Tue June 15 09:30–11:00 PDT (90m deep-dive). 30m follow-up Wed June 16 10:00 PDT.
- Option B: Thu June 17 13:00–14:15 PDT (75m deep-dive). 30m follow-up Mon June 21 09:00 PDT.

Agenda (high level):
1) Introductions & success criteria (10m)
2) Prompt playbook walk-through (20m)
3) Routing policy demo + canary variant (15m)
4) Load sweep: burst + steady-state (25–30m)
5) Observability + logs + SLA knobs (10m)
6) Action items & next steps (10m)

I'll attach the runbook and a short prompt checklist now. Ben will lead the load test plan; Sergio will own routing/canary. Dev will be on the call for infra/keys.

If either option works, we'll send calendar invites and a short pre-read bundle (slides, prompt checklist, load test CSV).

—Marissa
Solutions Lead, Redwood Inference

From: jdavenport@vertexhealth.com
To: marissa_cole@redwood.com; sara.patel@vertexhealth.com
Cc: ben_carter@redwood.com; sergio_alvarez@redwood.com; dev_patel@redwood.com
Date: 2027-06-06T08:47:00-07:00
Subject: Re: POC lab — proposed week for hands-on run

Marissa / team — thanks for the options. Option A (Tue 6/15 morning) collides with our leadership all-hands. Option B looks best for the core engineering group. Can we shift Option B earlier by 30 minutes so it ends before 14:30 (we have downstream interviews at 15:00 that day)?

Also: two prep notes from Eng:
- Please include a minimal test dataset for prompt validation (PII-free) so we can sanity-check outputs before the load sweep.
- For the load sweep, can you run one replicate with KV caching disabled so we can measure cold KVs?

Jake
Engineering Manager, VertexHealth

From: ben_carter@redwood.com
To: jdavenport@vertexhealth.com; sara.patel@vertexhealth.com
Cc: marissa_cole@redwood.com; sergio_alvarez@redwood.com; dev_patel@redwood.com; stephanie_nguyen@redwood.com
Date: 2027-06-06T11:22:00-07:00
Subject: Re: POC lab — proposed week for hands-on run

Jake — absolutely. We can start at 12:30 PDT on Thu June 17 and end by 13:45 PDT (75 minutes). I'll update the invite draft and include a 30m follow-up on Mon 6/21 at 09:00 PDT.

Notes / commitments from Redwood: 
- Attachments: "Redwood_POC_Runbook_v1.pdf", "Prompt_Review_Checklist.docx", "load_test_plan_10k_tokens.csv" (sent via Drive link in invite).
- We'll provide a scrubbed test dataset (CSV) and a run with KV cache disabled as requested.
- Routing demo will include two variant policies: latency-first and cost-safe fallback. Sergio will have the policy JSON available for the session.
- Dev will confirm that our temporary service account has log export enabled to the VertexHealth bucket (we'll share the policy snippet).

If that timing works, I'll finalize invites and drop the pre-read in the Drive folder.

-Ben
Senior Solutions Engineer, Redwood Inference

From: marissa_cole@redwood.com
To: sara.patel@vertexhealth.com; jdavenport@vertexhealth.com
Cc: ben_carter@redwood.com; sergio_alvarez@redwood.com; dev_patel@redwood.com; stephanie_nguyen@redwood.com
Date: 2027-06-08T15:47:00-07:00
Subject: Re: POC lab — confirmation + pre-read packet sent

Thanks everyone — confirmed calendar invite: Thu June 17 12:30–13:45 PDT (75m deep-dive). Follow-up: Mon June 21 09:00–09:30 PDT.

Pre-read bundle (Drive link in invite):
- Redwood_POC_Runbook_v1.pdf (overview, roles, rollback playbook)
- Prompt_Review_Checklist.docx (examples, test cases, redlines)
- load_test_plan_10k_tokens.csv (sweep matrix + expected targets)
- test_dataset_vertex_scrubbed.csv (PII-free samples for prompt verification)

Prep requests for VertexHealth: please review sections 2 & 3 of the runbook (success criteria and rollback triggers) and mark any additions in the shared doc by EOD Tue 6/15. We'll allocate the first 10 minutes of the session to align on those success criteria.

Open items:
- Sergio: route policy JSON and canary rollout snippet (to be uploaded to Drive by EOD 6/11).
- Dev: confirm service account permissions for log export by EOD 6/11.

If anything changes, ping me and we'll reshuffle. Looking forward to the hands-on lab.

—Marissa
Solutions Lead, Redwood Inference
