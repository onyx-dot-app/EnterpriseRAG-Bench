sara: Heads-up — quickstart README has a sample that tells folks to paste API_KEY into source. That's a copy/paste anti-pattern and leaks if they commit.
ben: which file? I can do a PR.
sara: docs/getting-started/quickstart.md near the python/node code fences. Node sample shows `const resp = client.generate(...)` then `console.log(resp)` — missing `await` so it actually logs a pending promise.
mike: SDK note: Node lib changed from sync-ish to async in 0.6. Docs missed the update. I'll own parity fix + add snippet tests.
olga: can we also avoid showing `API_KEY = 'sk-...'` in examples? Use `process.env.REDWOOD_API_KEY` and show a `.env` snippet. Lint flags secrets.
ben: PR opened: #3123 — updates node+python samples to use env, add await, add a note about auth/retry behavior for 401 vs 429. PTAL.
sara: also the node snippet used `import Redwood from 'redwood'` but package is `@redwood/inference` — please change.
mike: good catch. updating package name and adding a tiny runner test that executes the snippet with a fake key.
ben: snippet in old file:
```js
const { Redwood } = require('redwood')
const client = new Redwood({ apiKey: 'sk-...' })
const resp = client.generate({ model: 'rwd-small', prompt: 'hi' })
console.log(resp)
```
ben: fixed snippet:
```js
const { Redwood } = require('@redwood/inference')
const client = new Redwood({ apiKey: process.env.REDWOOD_API_KEY })
const resp = await client.generate({ model: 'rwd-small', prompt: 'hi' })
console.log(resp.text)
```
deploy-bot: docs/build succeeded for branch fix/quickstart-snippets — smoke tests passed :white_check_mark:
ben: merged to main. can someone confirm published page has correct fenced language? Node block was marked `bash` accidentally.
olga: fixed highlight and added a short note about safe key handling + KMS pointers.
sara: awesome, thanks all :tada: