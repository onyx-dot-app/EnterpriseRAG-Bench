Goal: Produce a compact set of reference screenshots and a minimal README flow diagram for the Template Apps quickstart that fit within the new docs compact layout.

Context:
- The docs team is introducing a condensed quickstart card for template apps used on the /quickstarts page. We need 6–8 annotated screenshots (desktop + one mobile highlight) and a single-page README flow diagram that explains first-run behavior and environment variables.
- Target audience: developers trying Redwood Inference with a template app (Node + Next.js starter). Focus on clarity, minimal copy, and visual parity with existing console UI (rollouts, model selector, logs).

Deliverables (acceptance criteria):
1) 6 annotated reference screenshots exported at 1440px wide (PNG) and 640px wide (mobile crop) that include: 1) repo clone + .env checklist, 2) local dev server running with Redwood token input modal, 3) console: model selector and latency-cost badge, 4) first call response showing streaming output, 5) rollout toggle + canary sample, 6) telemetry panel with token cost breakdown. Screens should be consistent with Figma component library and use Redwood colors/typography.
2) Single-page README flow diagram (SVG + PNG) that maps: Clone -> Install -> Set ENV -> Start -> Console Connect -> Make First Call -> View Telemetry. Diagram must be export-friendly for docs (800px height).
3) A README snippet (md) with inline images and alt text, copy limited to 120 characters per step.
4) A small captioned gallery for the quickstart card (3 images: hero, streaming, telemetry) sized for fast CDN delivery.

Notes on approach/constraints:
- Keep overlays minimal: use semi-transparent labels for key UI elements rather than full UI mockups. Avoid exposing any real API keys in images.
- Use generic sample content in responses (no PHI).
- Mobile crops should center on the chat stream and model selector for legibility.
- Follow accessibility contrast guidelines for annotation text (AA).

Progress updates / decisions / feedback log:
- 2026-02-12 (Aisha): Draft Figma file created: https://www.figma.com/file/REDWOOD-TEMPLATE-ONBOARDING (internal). Started with 8 screenshot frames.
- 2026-02-18 (Mateo): Reduced scope to 6 reference screens + 3-card gallery to speed up handoff for docs. Added acceptance criteria for image sizes.
- 2026-02-22 (PM - Lina Chen): Confirmed content scope with PM. Added explicit step for telemetry panel. PM requested copy that emphasizes cost transparency.
- 2026-02-26 (Engineering - Javier Ortiz): Flagged that streaming response state may differ locally; recommended using recorded sample JSON and static snapshot to avoid flakiness. Added link to sample response: https://github.com/redwood-inference/examples/blob/main/template-apps/sample_responses/streaming.json
- 2026-03-03 (Design review): Design review notes from Olivia Park: reduce annotation density, increase label font to 12px, and ensure rollouts toggle state is visible at 2x. Action: implement updates and export new assets.
- 2026-03-06 (Dev review): ENG-9072 provided a lightweight mock endpoint that returns deterministic output for screenshots. Confirmed by Mateo.
- 2026-03-09 (Copy review - Samir Patel): Shortened step copy to meet 120-char limit and added alt-text suggestions for each image.
- 2026-03-10 (This ticket): Assets uploaded to Drive and PR opened for docs insertion. Waiting on visual QA from docs team and final signoff from PM.

Links & artifacts:
- Figma master (internal): https://www.figma.com/file/REDWOOD-TEMPLATE-ONBOARDING
- Drive: https://drive.google.com/drive/folders/REDWOOD_TEMPLATE_ONBOARDING_ASSETS
- Sample response (github): https://github.com/redwood-inference/examples/tree/main/template-apps/sample_responses
- Docs PR (draft): https://github.com/redwood-inference/docs/pull/542

Open items / blockers:
- Visual QA by docs (requested 2026-03-10) for image export compression settings (PNG vs WebP).
- Confirm final hero image crop used by marketing for CDN (need marketing input by 2026-03-13).

Acceptance checklist (to be checked off in PR):
- [ ] All 6 desktop PNGs exported and verified at 1440px width
- [ ] Mobile crops exported at 640px width and visually inspected
- [ ] README flow diagram exported as SVG + PNG and added to PR
- [ ] README snippet (md) with inline images and alt text included in PR
- [ ] Gallery captions written and approved by PM
- [ ] Docs PR updated and assigned to docs reviewer

If any of the blockers remain past 2026-03-13, escalate to Lina Chen (PM) for prioritization.
Export settings recommended: PNG-24 for transparency screenshots, WebP (lossless) for gallery hero to save CDN bytes. Provide alt text in README and captions in CMS metadata.
figma:REDWOOD-TEMPLATE-ONBOARDING
drive:/REDWOOD_TEMPLATE_ONBOARDING_ASSETS/exports/desktop/
drive:/REDWOOD_TEMPLATE_ONBOARDING_ASSETS/exports/mobile/
github:docs/pull/542
github:examples/template-apps/sample_responses/streaming.json