erin: Heads-up from onboarding: new hires ran `pip install redwood` from our quickstart and ended up with a different project. Import collisions.

erin: Repro:
```bash
python -m venv venv
source venv/bin/activate
pip install redwood
python -c 'import redwood; print(redwood.__file__, getattr(redwood, "__version__", "no-version"))'
```

erin: Output pointed to `/usr/lib/python/site-packages/redwood` (not our wheel) and version was `0.3.1`. Oops.

rafael: Ah right, distribution name is `redwood-inference` but top-level package is `redwood`. If user types `pip install redwood` pip grabs the other project. We should never encourage `pip install redwood` in README.

lydia: Also seeing type-check failures in the onboarding repo: mypy complains about missing imports. I inspected our sdist/wheel and there's no `py.typed` file and no `package_data`. So types are invisible to tooling.

harry: Is AsyncClient missing for them too? Sentry shows a few stacktraces: ImportError: cannot import name 'AsyncClient' from 'redwood'

erin: They followed code sample `from redwood import AsyncClient` in README. But our async code lives behind extras and a submodule: `redwood.async_` and we expose sync default. The README doesn't mention `[async]` extras.

rafael: Quick fixes we should push: (A) Immediately update README to `pip install redwood-inference` and in async examples `pip install "redwood-inference[async]"`; (B) ship a patch release that includes `py.typed` in the wheel and declares optional-deps for async; (C) add CI check that inspects built wheel for `redwood/py.typed`.

lydia: For packaging changes, adding `py.typed` is low risk. We should also include `__all__` exports at top-level so `from redwood import AsyncClient` works when async extra installed. That avoids user confusion.

harry: Long-term options: rename top-level package to avoid collision (e.g., `redwood_inference`) or publish a tiny shim package named `redwood` that pins/depends on our package and re-exports symbols. Shim is fast but means we hold the `redwood` distribution name. Renaming is breaking.

erin: I'm leaning shim + docs first. We'll use the shim only as a short-lived transitional package with a clear deprecation notice. Meanwhile prepare a 2.0 plan for rename/alias if we want to break compat.

dev-bot: Action created: PACKAGING-421 - "Fix py.typed, extras, README and confirm wheel contains py.typed" assigned to rafael.

rafael: Patch proposal for pyproject.toml: add `include = ["redwood/py.typed"]` and under `[project.optional-dependencies]` put `async = ["httpx[http2]>=0.24"]`. Also update `packages = ["redwood"]` stays the same.

lydia: For editable dev installs (pip install -e .) sometimes MANIFEST or include settings miss package_data. We should update tests: in release workflow unzip wheel and assert `redwood/py.typed` exists; in dev workflow assert copy of `py.typed` is present when running `pip install -e .`.

harry: Also run a quick grep on all our docs and examples to replace any `pip install redwood` occurrences. I'll open a docs PR.

erin: Good. I'll add a blurb to the onboarding checklist so new hires avoid the ambiguous command.

rafael: I'll cut a 1.1.2 hotfix with these minimal changes. Will also publish a tiny `redwood` shim package that depends on `redwood-inference==1.1.2` and re-exports `from redwood import *` style wrappers to reduce breakage for existing tutorials. We'll mark shim as transitional and require it to be yanked after 6 months.

dev-bot: CI run started: packaging-check/181010 (verify wheel contains py.typed).

erin: Thanks all. Once hotfix is out, I'll follow up with an internal note and update the onboarding repo.

dev-bot: CI run passed: packaging-check/181010 - wheel contains redwood/py.typed. Release 1.1.2 uploaded as prerelease.