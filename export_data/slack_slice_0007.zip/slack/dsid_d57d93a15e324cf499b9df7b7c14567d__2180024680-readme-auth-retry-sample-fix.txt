jia: Found another README drift in examples/getting-started. The retry section still references client.retryPolicy.maxAttempts (old API) and the Python snippet calls client.generate_sync(), which no longer exists. Customers are confused.

kevin: Oof. Which file exactly?

jia: examples/getting-started/README.md — under "Retries and backoff". Current text:

```md
// JavaScript
const client = new RedwoodClient({ apiKey: process.env.API_KEY })
client.retryPolicy.maxAttempts = 3
await client.generate({ input: 'hello' })
```

And Python shows:

```py
# old
result = client.generate_sync('hello')
```

kevin: Yeah that's from API v0.x -> v1. We renamed retry config to retry.max_retries and Python now uses generate(...) coroutine.

lee: Also the curl example is inconsistent: header uses "Authorization: Token" instead of "Authorization: Bearer". That breaks out-of-the-box examples for people copying curl.

jia: Proposed canonical changes: use REDWOOD_API_URL and REDWOOD_API_KEY, explicit https://, and update snippets to current SDK shapes. Example replacements below.

```bash
export REDWOOD_API_URL=https://api.redwood.ai
export REDWOOD_API_KEY=sk-REPLACE

curl "$REDWOOD_API_URL/v1/generate" \
  -H "Authorization: Bearer $REDWOOD_API_KEY" \
  -H "Content-Type: application/json" \
  -d '{"input":"hello"}'
```

```js
// Node (current)
import RedwoodClient from '@redwood/inference'
const client = new RedwoodClient({ apiKey: process.env.REDWOOD_API_KEY, apiUrl: process.env.REDWOOD_API_URL })
client.retry.max_retries = 3
await client.generate({ input: 'hello' })
```

```py
# Python (current, sync wrapper)
from redwood import RedwoodClient
client = RedwoodClient(api_key=os.environ['REDWOOD_API_KEY'], api_url=os.environ['REDWOOD_API_URL'])
client.retry.max_retries = 3
result = client.generate('hello')  # blocks in sync wrapper
```

kevin: Please also add a short note: "SDKs automatically add the Authorization header when configured with an API key; do not add a manual header when using the client." That avoids duplicate header confusion.

lee: I'll update the Go example to use client.New(...) instead of raw header usage. Also we'll run the example against staging to validate.

docs-bot: opened docs PR #3478 with the suggested edits and a link to staging smoke tests.

linter-bot: docs lint failed on PR 3478: missing blank line before fenced code block and trailing spaces on line 42.

jia: I'll fix formatting and push a follow-up commit. Thanks team. These small drift issues are a big UX tax. :disappointed_relieved: