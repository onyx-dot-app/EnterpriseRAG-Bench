sam.devex: Heads up — the README in the realtime-samples repo has an auth snippet that's out of sync with the SDK. The curl quickstart uses `Authorization: Token <KEY>` but our Go and JS SDK examples expect `Bearer <KEY>`. Caused confusion during onboarding this morning.

mia.docs: Sorry about that, ugh. Can you paste the exact section so I can patch it? :grimacing:

riley-engineer: I ran into this when testing the docker-compose quickstart — env in `docker-compose.yml` is `REDWOOD_API_KEY` but the README example shows `REDWOOD_TOKEN`. So two mismatches in one sample. Repro steps: start the container, attempt `curl` and you get 401.

sam.devex: Paste below — original README curl (wrong header):

```bash
curl -X POST https://api.redwood.ai/v1/generate \n  -H "Content-Type: application/json" \n  -H "Authorization: Token $REDWOOD_TOKEN" \n  -d '{"model":"gpt-mini","input":"hello"}'
```

And the Go snippet in the same README uses `WithToken("$REDWOOD_API_KEY")` — so folks copy/paste and wonder why the header doesn't match the env var.

jamal-se: I can open a tiny PR to: (1) normalize env var to `REDWOOD_API_KEY` everywhere, (2) change curl header to `Authorization: Bearer $REDWOOD_API_KEY`, (3) add a one-line note about where to store keys in docker-compose. Also suggest adding a short troubleshooting bullet: "401 -> check header and env var name". Sound good? :+1:

mia.docs: Yes please. If you include the before/after snippets in the PR description that speeds review. Also add a tiny unit test for the example workspace that runs the curl against a mocked endpoint (just to catch regressions).

jamal-se: Will do. I'll also add a brief note about SDK retry semantics — the quickstart implies retries are automatic for idempotent requests but our JS SDK only retries token-refreshable 429s by default. Suggest clarity text: "SDKs implement limited automatic retries; for production you should configure your retry/backoff policy via the SDK options."

riley-engineer: One more gotcha — the README shows `sdk.NewClient(ctx, apiKey)` while our JS/TS SDK wants `new RedwoodClient({ apiKey: process.env.REDWOOD_API_KEY })`(different shape). We should standardize on explicit examples per language.

alex-bot: PR opened by jamal-se: https://github.com/redwood-inference/realtime-samples/pull/321 — updates README, docker-compose env, and adds troubleshooting note. CI started. :rocket:

mia.docs: Awesome — thanks everyone. After merge I'll cut a tiny patch release of the sample and update the quickstart landing page to point to the fixed example.

sam.devex: Thanks — this should cut down on onboarding support tickets.
