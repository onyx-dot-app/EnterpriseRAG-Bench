Produce a cohesive set of visual assets for the Template Apps quickstart: a responsive screenshot gallery (desktop/tablet/phone) showcasing the reference app first-run flows, and a set of README-friendly stateflow diagrams that explain bootstrapping (create API key -> local dev -> connect to hosted/dedicated/private modes). These assets will be used across docs, GitHub READMEs, and the Console onboarding panel.
Audit existing reference app screens and identify 6 canonical states (welcome, api-key-modal, sample-prompt, streaming-response, settings/region, error-fallback)
Design a responsive screenshot grid (3-breakpoints) and export optimized PNG/SVG sets for web and markdown README use
Create simplified stateflow diagrams (light + dark variants) that fit within 640x360 and 1200x628 aspect ratios
Write short captions and alt-text for each screenshot for accessibility and docs ingestion
Package assets with a usage guide and example markdown snippets for repo READMEs
Run design review with PM (Marco Diaz) and engineering reviewer (ENG-4821) and iterate on feedback
Finalize deliverables and upload to Drive; add links to PR and docs ticket
6 annotated screenshots exported in desktop/tablet/mobile sizes and compressed below 250KB each for README use
2 diagram variations (linear stateflow and swimlane) exported as SVG and PNG; both light and dark color schemes
Markdown-ready snippet demonstrating how to embed gallery and include captions/alt-text
Design review completed and approval recorded in comments with timestamp
Files uploaded to Drive folder and drive link added to ticket; GitHub PR references the Drive assets
Primary visual goal is clarity at small sizes for README thumbnails. Use the system UI theme tokens and ensure text overlays meet 4.5:1 contrast for accessibility. For first-run flow diagrams, prefer simple rounded rectangles + arrows and annotate optional steps (hosted vs dedicated vs private) with dashed lines. Keep iconography to the existing Redwood icon set to align with brand.