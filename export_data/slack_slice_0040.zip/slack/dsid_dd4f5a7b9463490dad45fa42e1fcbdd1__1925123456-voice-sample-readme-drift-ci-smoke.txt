erin: ran the onboarding workshop and noticed the speech sample README still has old snippets (env var REDWOOD_KEY_OLD, and the curl posts to /v0/stream). new hires got stuck.
leo: can you paste the curl?
erin: ```bash
curl -X POST \
  -H \"Authorization: Bearer $REDWOOD_KEY_OLD\" \
  -H \"Content-Type: application/json\" \
  https://api.redwood.ai/v0/stream \
  -d '{"text":"hello"}'
```
maya: ah yes, that base URL and env name changed last year. also the JS example still imports `@redwood/inference` instead of `@redwood-inference/sdk`. classic copy/paste drift.
erin: i started a small PR to fix the readme and update package.json: https://github.com/redwood-inference/samples/pull/4332 (title: \"fix(samples): update curl/env, fix imports, add CI smoke\").
leo: nice. what else did you tweak?
erin: swapped node-fetch -> undici, set \"type\":\"module\" in package.json to avoid ESM issues on node20, and added a non-blocking samples-smoke CI job that runs `npm ci && node examples/voice/index.mjs`.
maya: can we avoid claiming SDK parity in the README? it had a line like \"retry defaults match Python\" which isn't true. JS uses jittered exponential backoff by default. i added a short note: \"Retry defaults vary by client; see /docs/retries.md for per-SDK behavior.\"
leo: good. also added a CONTRIBUTING checklist entry: \"when touching samples, verify env names, example imports, and run local smoke test\" so future PRs don't regress.
erin: docs-bot flagged a broken link to ./examples/stream/index.mjs while editing; fixed that too.
ci-bot: samples-smoke workflow: queued (non-blocking).
leo: filed issue #1045 to follow up: automate link-check + run quick sample smoke tests for all sample dirs (low priority).
maya: thanks team. once CI is green i'll merge the PR. small wins for onboarding UX :rocket: