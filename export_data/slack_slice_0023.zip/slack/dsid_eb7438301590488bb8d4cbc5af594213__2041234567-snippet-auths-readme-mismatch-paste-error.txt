morgan: Hey, heads up — the Node quickstart in docs/quickstarts/node/README.md has the API example hard-coded and uses the old 'Redwood.create' API. Causing auth failures and a bunch of users pasting keys into public repos :grimacing:

alejandro: oh no. do you have the snippet?

morgan: yup — here's the paste (from the README):
```js
const client = Redwood.create("sk-live-xxxx");
const res = await client.generate({ model: "redwood-alpha", prompt: "Hello" });
console.log(res.text);
```
error I saw: "401 Unauthorized — invalid api key"

sasha: ugh. that pattern :facepalm: we switched to env var pattern and renamed constructor to RedwoodClient last quarter. docs must have missed it during parity updates.

tyler: also the snippet lacks retry/backoff and streaming example. recommend changing to:
```js
const client = new RedwoodClient({ apiKey: process.env.REDWOOD_API_KEY, retries: 3 });
const stream = await client.stream({ model: "redwood-alpha", prompt: "Hello" });
for await (const chunk of stream) console.log(chunk.text);
```

alejandro: can we patch README quickly? which repo/path?

morgan: docs repo at https://github.com/redwood-inference/docs, file path /quickstarts/node/README.md. I'm happy to open PR with small patch. Also we should add a linter check to flag literal-looking keys (sk- or pk- prefixes) in docs.

docs-bot: reminder — include changelog note and update the snippet test harness (scripts/quickstart-tests/node-snippets.spec.js).

sasha: agreed. +1 for snippet tests and a regex in CI to fail if literal-looking keys are present.

tyler: i'll make a tiny ESLint rule for the docs repo and add the snippet update to my sprint. alejandro, can you review PR?

alejandro: yep. assign to me when ready.

morgan: opened PR #842 — includes updated snippet, streaming example, env var usage, and added docs test. Link: https://github.com/redwood-inference/docs/pull/842

tyler: reviewed and left minor comments. lgtm after fixes.

alejandro: merged. deployed docs site — new quickstart live at https://docs.redwood.ai/quickstarts/node/

morgan: thanks y'all. can we also search other READMEs for similar hard-coded keys? I can run a grep across repo.

sasha: please do. post results here and open issues per file.